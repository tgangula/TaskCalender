/*global define */

// Author: Loïc Knuchel <loicknuchel@gmail.com>

define({
	ENTER_KEY: 13,
	ESCAPE_KEY: 27,
	localStorageItem: 'todos-knockout-require'
});
